import pandas as pd
import numpy as np
import random

# Define product types with ideal storage temperature ranges (°C)
products = {
    'Milk': (2, 4),
    'Butter': (8, 10),
    'Ice Cream': (-25, -18),
    'Cheese': (2, 8),
    'Curd': (4, 8),
    'Flavored Drink': (2, 6)
}

# Packaging types and airflow ratings
packaging_types = ['Plastic', 'Glass', 'Tetra Pak', 'Carton', 'Poly Bag']
airflow_ratings = ['Low', 'Medium', 'High']

# Function to generate ideal temperature based on product
def get_ideal_temp(product):
    return round(np.random.uniform(*products[product]), 1)

# Generate 10,000 samples
data = []
for _ in range(10000):
    product = random.choice(list(products.keys()))
    external_temp = round(np.random.uniform(-5, 45), 1)  # in °C
    current_room_temp = round(np.random.uniform(-20, 30), 1)  # in °C
    humidity = round(np.random.uniform(30, 90), 1)  # in %
    volume_kg = round(np.random.uniform(1, 100), 1)  # in kg
    packaging = random.choice(packaging_types)
    storage_time_hr = round(np.random.uniform(1, 168), 1)  # up to 7 days
    airflow = random.choice(airflow_ratings)
    ideal_temp = get_ideal_temp(product)

    data.append([
        product,
        external_temp,
        current_room_temp,
        humidity,
        volume_kg,
        packaging,
        storage_time_hr,
        airflow,
        ideal_temp
    ])

# Create DataFrame
df = pd.DataFrame(data, columns=[
    'product_type',
    'external_temp',
    'current_room_temp',
    'humidity',
    'volume_kg',
    'packaging_type',
    'storage_time_hr',
    'airflow_rating',
    'ideal_room_temp'
])

# Save to CSV
df.to_csv('synthetic_dairy_temp_dataset.csv', index=False)
print("✅ Dataset created with 10,000 samples: 'synthetic_dairy_temp_dataset.csv'")
