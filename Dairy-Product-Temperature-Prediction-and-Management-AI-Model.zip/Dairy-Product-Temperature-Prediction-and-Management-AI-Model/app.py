import streamlit as st
import pandas as pd
import joblib
import plotly.express as px
import smtplib
from email.mime.text import MIMEText

# Load the trained model
model = joblib.load('improved_rf_temp_model.pkl')

# Title
st.set_page_config(page_title="Smart Dairy Temp Control", layout="centered")
st.title("🧊 Smart Environment Temp Control for Dairy Products")

# --- Form UI ---
st.header("📋 Enter Storage Details")

product_type = st.selectbox("Product Type", ['Milk', 'Butter', 'Ice Cream', 'Cheese', 'Curd', 'Flavored Drink'])
external_temp = st.slider("External Temperature (°C)", -5.0, 45.0, 25.0)
current_room_temp = st.slider("Current Room Temperature (°C)", -25.0, 30.0, 5.0)
humidity = st.slider("Humidity (%)", 30.0, 90.0, 60.0)
volume_kg = st.number_input("Volume (kg)", 1.0, 100.0, 20.0)
packaging_type = st.selectbox("Packaging Type", ['Plastic', 'Glass', 'Tetra Pak', 'Carton', 'Poly Bag'])
storage_time_hr = st.slider("Storage Duration (hours)", 1, 168, 24)
airflow_rating = st.selectbox("Airflow Rating", ['Low', 'Medium', 'High'])

# Email input for alerts
email = st.text_input("📧 Enter your Email for Alerts (optional)", "")

# Alert thresholds by product type

product_thresholds = {
    'Milk': 1.0,
    'Butter': 2.0,
    'Ice Cream': 2.5,
    'Cheese': 1.5,
    'Curd': 1.5,
    'Flavored Drink': 1.5
}


# Create a DataFrame from input
input_df = pd.DataFrame([{
    'product_type': product_type,
    'external_temp': external_temp,
    'current_room_temp': current_room_temp,
    'humidity': humidity,
    'volume_kg': volume_kg,
    'packaging_type': packaging_type,
    'storage_time_hr': storage_time_hr,
    'airflow_rating': airflow_rating
}])

# Prediction button
if st.button("🔍 Predict Ideal Room Temperature"):
    prediction = model.predict(input_df)[0]
    st.success(f"✅ Predicted Ideal Room Temperature: **{round(prediction, 2)}°C**")

    # Alert logic
    threshold = product_thresholds.get(product_type, 2)
    temp_deviation = abs(prediction - current_room_temp)
    
    if temp_deviation > threshold:
        alert_msg = f"""
        ⚠️ ALERT: Temperature mismatch detected for {product_type}!

        ✅ Ideal Temp: {round(prediction, 2)} °C  
        ❌ Current Temp: {current_room_temp} °C  
        ❗ Deviation exceeds {threshold} °C  

        Please take action to avoid spoilage.
        """
        st.error(alert_msg)

        if email:
            try:
                msg = MIMEText(alert_msg)
                msg['Subject'] = f"[ALERT] Temp Deviation Detected for {product_type}"
                msg['From'] = 'aryanprasad2118@gmail.com'
                msg['To'] = email

                # Configure SMTP server (use Gmail or any SMTP server)
                smtp_server = "smtp.gmail.com"
                smtp_port = 587
                smtp_user = "aryanprasad2118@gmail.com"
                smtp_pass = "2118"

                server = smtplib.SMTP(smtp_server, smtp_port)
                server.starttls()
                server.login(smtp_user, smtp_pass)
                server.sendmail(smtp_user, email, msg.as_string())
                server.quit()

                st.success(f"📧 Email alert sent to {email}!")
            except Exception as e:
                st.error(f"Email sending failed: {str(e)}")

# --- Temperature Graph ---
st.header("📊 Temperature Distribution by Product")
df = pd.read_csv("synthetic_dairy_temp_dataset.csv")

# Plot
fig = px.box(df, x='product_type', y='ideal_room_temp',
             color='product_type', title='Ideal Room Temp Distribution per Product')
st.plotly_chart(fig, use_container_width=True)
