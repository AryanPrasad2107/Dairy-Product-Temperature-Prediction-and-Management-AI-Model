import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.impute import SimpleImputer
import joblib

# Step 1: Load dataset
df = pd.read_csv("synthetic_dairy_temp_dataset.csv")

# Step 2: Drop extreme outliers in temperature (optional, improves MAE)
df = df[(df['current_room_temp'] > -30) & (df['current_room_temp'] < 35)]

# Step 3: Feature and target separation
X = df.drop(columns=['ideal_room_temp'])
y = df['ideal_room_temp']

# Step 4: Categorical and numerical columns
categorical_features = ['product_type', 'packaging_type', 'airflow_rating']
numerical_features = [col for col in X.columns if col not in categorical_features]

# Step 5: Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('num', SimpleImputer(strategy='median'), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ]
)

# Step 6: Define a tuned RandomForestRegressor
rf_model = RandomForestRegressor(
    n_estimators=300,
    max_depth=20,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    n_jobs=-1
)

# Step 7: Create pipeline
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', rf_model)
])

# Step 8: Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Step 9: Train the model
pipeline.fit(X_train, y_train)

# Step 10: Evaluate
y_pred = pipeline.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("✅ Improved model trained using original dataset and structure.")
print(f"🔍 MAE: {mae:.2f} °C")
print(f"📈 R² Score: {r2:.2f}")

# Step 11: Save the model
joblib.dump(pipeline, 'improved_rf_temp_model.pkl')
print("📦 Model saved as 'improved_rf_temp_model.pkl'")
